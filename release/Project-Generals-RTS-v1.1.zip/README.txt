Project Generals - RTS.exe milestone build (release 1.1)
========================================================

What this is
------------
Cross-compiled Windows x64 build of the C&C Generals / Zero Hour source
port to native Vulkan + MinGW (see NOTES.md). This is a LINK MILESTONE:
the binary links and loads; gameplay/audio/video backends are still stubs.

Run
---
Extract the whole folder and run RTS.exe on Windows 10+ x64.

Bundled DLLs (required, keep next to RTS.exe):
  libgcc_s_seh-1.dll        (MinGW runtime)
  libstdc++-6.dll           (MinGW runtime)
  libwinpthread-1.dll       (MinGW runtime)
  OpenAL32.dll              (OpenAL Soft - Miles audio backend)
  vulkan-1.dll              (Khronos Vulkan loader - real, not stubs)

Audio: Miles SDK calls route to OpenAL Soft (Source/MSS/mss.cpp).
Graphics: RTS.exe links the real vulkan-1.dll (KhronosLoader, MinGW build).
A Vulkan-capable GPU/driver (ICD) is still required to actually render.

Video: Bink (.bik) cutscenes decode via static FFmpeg (libavformat/libavcodec).
No extra video DLLs — FFmpeg is linked in. bcrypt.dll is a Windows system DLL.

Windows provides: ADVAPI32, DINPUT8, GDI32, KERNEL32, SHELL32, USER32,
WINMM, WS2_32, AVIFIL32, IMM32, and the api-ms-win-crt-* UCRT set.

Not yet linked (future releases): OpenAL32.dll (Miles->OpenAL), SDL2.dll,
vulkan-1.dll (loader; current build uses in-tree vk* stubs so the real
loader is not imported).

Known state (see PROGRESS.md / NOTES.md)
----------------------------------------
- All engine targets compile; RTS.exe is a real PE32+ x86-64 GUI binary.
- Vulkan backend present but loader calls are stubbed for this link.
- Miles audio / Bink video / GameSpy are compile stubs, not real backends.
- GeneralsMD tree not yet mirrored.

Repo: https://github.com/Lyky35/Project-Generals
