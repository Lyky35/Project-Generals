Project Generals - RTS.exe milestone build (release 1.1)
========================================================

What this is
------------
Cross-compiled Windows x64 build of the C&C Generals / Zero Hour source
port to native Vulkan + MinGW (see NOTES.md). This build boots past CRT
static init, creates the game window and inits the memory manager, then
enters GameMain. Actual gameplay needs the real game data files.

Run
---
Extract the whole folder and run RTS.exe on Windows 10+ x64, ideally next
to an installed copy of Generals / Zero Hour (the game data .big archives
and Data\ folder are required to get past GameMain init).

Bundled DLLs (required, keep next to RTS.exe):
  libwinpthread-1.dll       (MinGW runtime; libgcc/libstdc++ are static)
  OpenAL32.dll              (OpenAL Soft - Miles audio backend)
  vulkan-1.dll              (Khronos Vulkan loader - real, linked)

Audio: Miles SDK calls route to OpenAL Soft (Source/MSS/mss.cpp).
Graphics: RTS.exe links the real vulkan-1.dll; a Vulkan-capable GPU/driver
(ICD) is required to actually render.

Video: Bink (.bik) cutscenes decode via static FFmpeg (libavformat/libavcodec).
No extra video DLLs - FFmpeg is linked in. bcrypt.dll is a Windows system DLL.

Windows provides: ADVAPI32, DINPUT8, GDI32, KERNEL32, SHELL32, USER32,
WINMM, WS2_32, AVIFIL32, IMM32, and the api-ms-win-crt-* UCRT set.

Known state (see PROGRESS.md / NOTES.md)
----------------------------------------
- All engine targets compile; RTS.exe is a real PE32+ x86-64 GUI binary.
- Boot verified under wine: static init -> WinMain -> window -> memory
  manager -> GameMain. GameMain init currently needs real game data.
- Fixed in this build: Win10 pre-WinMain crash (uninitialized os_info.Code
  in Get_OS_Info for NT major >= 6) and an initMemoryManager exit(-1)
  caused by GCC folding the operator new/delete link test.
- Real Vulkan loader linked (no vk* stubs). Miles audio = OpenAL Soft.
- GeneralsMD tree not yet mirrored.

Repo: https://github.com/Lyky35/Project-Generals


Troubleshooting
---------------
RTS_START.LOG  - written next to RTS.exe. Boot markers run first
                 (static-init ... late-static-done), then WinMain
                 breadcrumbs (WinMain enter, initializeAppWindows ok,
                 initMemoryManager done, entering GameMain). If RTS.exe
                 dies with an unhandled exception, CRASH lines follow with
                 the faulting module and a full FR0..FRn stack walk.
RTS_DIAG.exe   - tiny helper: loads OpenAL32.dll + vulkan-1.dll via LoadLibrary.
                 Run it next to the DLLs. If it shows a message box, those DLLs
                 are fine and any RTS.exe crash is in our static init / code.
                 Check RTS_DIAG.LOG for which DLL failed.
